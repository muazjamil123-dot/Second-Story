import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// base: "./" makes all built asset paths relative, so the site works
// correctly when served from a GitHub Pages project URL like
// https://username.github.io/repo-name/ regardless of the repo name.
export default defineConfig({
  plugins: [react()],
  base: "./",
});
