# Second Story

Website for Second Story — a thrift, vintage & rewear shop.

## Stack

- React 18 + Vite
- Tailwind CSS
- [lucide-react](https://lucide.dev/) for icons

## Getting started

```bash
npm install
npm run dev
```

Then open the local URL Vite prints (usually `http://localhost:5173`).

## Build for production

```bash
npm run build
npm run preview   # preview the production build locally
```

The production files land in `dist/`.

## Notes

- The checkout flow (cart → payment form → confirmation) is a **front-end
  demo only**. No card details are sent anywhere or stored. To take real
  payments, connect the checkout step to a backend + payment processor
  (e.g. Stripe) — see `handleSubmit` in the `CartDrawer` component in
  `src/App.jsx`.
- Fonts (Bodoni Moda, Libre Franklin) load from Google Fonts via `@import`
  in `src/App.jsx`.
- The logo mark (hanger merged into the "O", and the circular "SS"
  monogram) is hand-built as inline SVG in `src/App.jsx` — no image assets
  needed.
